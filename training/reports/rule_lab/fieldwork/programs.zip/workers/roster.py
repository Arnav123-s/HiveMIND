from bisect import bisect_right, bisect_left

def solve(x):
    jobs = sorted(x["jobs"], key=lambda row: row[1])
    ends = [r[1] for r in jobs]
    scores = [[(0, 1), (None, 0)]]
    for i, (start, end, reward, marked) in enumerate(jobs):
        bound = start-x['gap']
        earlier = bisect_right(ends, bound, 0, i)
        best = list(scores[-1])
        for before, (value, ways) in enumerate(scores[earlier]):
            if value is None:
                continue
            after = before ^ marked
            total = value + reward
            previous, count = best[after]
            if previous is None or total > previous:
                best[after] = (total, ways)
            elif total == previous:
                best[after] = (total, (ways + count) % 1000000007)
        scores.append(best)
    return list(scores[-1][1])
