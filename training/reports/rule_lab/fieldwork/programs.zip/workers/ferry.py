_school_scope = {'least_squares': least_squares}
exec("def solve(x):\n    out = []\n    for r in x['rows']:\n        grid = r[1] + (max(0, -(-(r[0]-r[1])//r[2]))) * r[2]\n        out.append(grid + r[4] if grid <= r[3] else None)\n    return out", _school_scope)
skill_departure = _school_scope['solve']
from heapq import heappush, heappop

def solve(x):
    n, src, dst = x["n"], x["src"], x["dst"]
    graph = [[] for _ in range(n)]
    for u,v,first,step,last,duration in x["edges"]:
        graph[u].append((v,first,step,last,duration))
    times = [[float("inf"),float("inf")] for _ in range(n)]
    times[src][0] = x["start"]
    queue = [(x["start"],src,0)]
    while queue:
        now,u,used = heappop(queue)
        if now != times[u][used]:
            continue
        wait = x['lay'][u]
        for v,first,step,last,duration in graph[u]:
            for spend in range(2-used):
                ready = now if spend else now+wait
                arrive = skill_departure({"rows":[[ready,first,step,last,duration]]})[0]
                state = used+spend
                if arrive is not None and arrive < times[v][state]:
                    times[v][state] = arrive
                    heappush(queue,(arrive,v,state))
    choices = [0,1]
    idx = min(choices,key=lambda j: (times[dst][j], j))
    return [None,None] if times[dst][idx] == float("inf") else [times[dst][idx],idx]
