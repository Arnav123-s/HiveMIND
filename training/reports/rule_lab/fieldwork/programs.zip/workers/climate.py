import numpy as np

def seasonal(past, future, window, degree):
    past = np.asarray(past[-12 * window :], float)
    center = past[-1, 0] + (past[-1, 1] - 1) / 12

    def design(rows):
        rows = np.asarray(rows, float)
        t = rows[:, 0] + (rows[:, 1] - 1) / 12 - center
        cols = [np.ones_like(t), t] + ([t * t] if degree == 2 else [])
        return np.column_stack(cols + [rows[:, 1] == m for m in range(2, 13)])

    coef = np.linalg.lstsq(design(past), past[:, 2], rcond=None)[0]
    pred = design(future) @ coef
    offsets = [0] + list(coef[degree + 1 :])
    return pred, float(coef[1]), int(np.argmax(offsets)) + 1


def atmosphere(x, choose=True):
    history, future = x["history"], x["future"]
    scored = []
    for window in (5, 10, 15):
        for degree in (1, 2):
            errors = []
            for hold in (24, 36, 48, 60):
                cutoff = len(history) - hold
                test = history[cutoff : cutoff + 24]
                pred, _, _ = seasonal(history[:cutoff], test, window, degree)
                errors.extend(np.array([r[2] for r in test]) - pred)
            scored.append((float(np.sqrt(np.mean(np.square(errors)))), window, degree))
    rank, window, degree = min(scored) if choose else next(k for k in scored if k[1:] == (10, 1))
    predicted, _, _ = seasonal(history, future, window, degree)
    _, slope, peak = seasonal(history, future, 10, 1)
    return dict(
        forecast=predicted.tolist(),
        trend=slope,
        peak_month=peak,
        validation_rmse=rank,
        method=f"Calendar-month offsets and polynomial degree {degree}, {window}-year window; ten-year linear slope and seasonal peak.",
    )


def solve(x):
    return atmosphere(x, choose=True)